from ultralytics import YOLO # type: ignore
import cv2

# model path
model = YOLO(r"C:\Users\user\yolo26s.pt")

#開啓攝像機並把資料存到camera
camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)

#固定視窗
cv2.namedWindow("Camera", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Camera", 800, 600)


while True:
    #讀取畫面
    success, frame = camera.read()
    if not success:
        print("cannot read camera")
        break

    # predict image
    results = model.predict(
        source=frame,
        conf=0.3,          # confidence threshold
        imgsz=640,         # inference image size
        device="cpu",      # use CPU
        save=False,         # save image
        show=False, #show boxes


        #for save, save for later
        project="results",
        name="test",
        exist_ok=True,
    )

    for result in results: #result list
        #繪畫yolo偵測結果到圖片上
        annotated_frame = result.plot()
        cv2.imshow("Camera", annotated_frame)
        image_height, image_width = result.orig_shape #orignal resulution

        for box in result.boxes: # result boxes
            
            #get type cofident and xy coords
            class_id = int(box.cls.item())
            class_name = result.names[class_id]
            confidence = float(box.conf.item())
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            
            
            # 計算中心點
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2
            
            
            #make the data
            data = {
                "class_id": class_id,

                "class_name": class_name,
                "confidence": confidence,
                "bbox_xyxy": [x1, y1, x2, y2],
                "center_xy": [center_x, center_y],
                "normalized_center": [
                    center_x / image_width,
                    center_y / image_height,
                ],
            }
            #分類遇到人或者物件 
            if class_name == "person":
                print("person")
                print(data)
            else:
                print("item")
                print(data)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

camera.release()
cv2.destroyAllWindows()